
import java.io.*;
import java.net.*;
import java.util.*;

public class Results {
  Hashtable votes,totvotes;
  Set ips;

  public Results() {
    votes = new Hashtable();
    totvotes = new Hashtable();
    ips = new HashSet();
  }

  public void addVote(String vote, InetAddress addr) {
    if (!ips.contains(addr)) {
      ips.add(addr);
      Integer r = (Integer)votes.get(vote);
      if (r == null) {
	votes.put(vote,new Integer(1));
      } else {
	votes.put(vote,new Integer(1+r.intValue()));
      }
    }
    Integer r = (Integer)totvotes.get(vote);
    if (r == null)
      totvotes.put(vote,new Integer(1));
    else
      totvotes.put(vote,new Integer(1+r.intValue()));
  }
  
  public void output(PrintWriter out) {
    ArrayList l = new ArrayList(totvotes.keySet());
    Collections.sort(l);
    out.println(l.size());
    Iterator i = l.iterator();
    while (i.hasNext()) {
      String key = (String)i.next();
      out.println(key);
      Integer r = (Integer)votes.get(key);
      out.println(r == null ? "0" : r.toString());
      out.println(totvotes.get(key));
    }
    out.flush();
    out.close();
  }

}
