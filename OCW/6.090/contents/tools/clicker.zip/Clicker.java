import java.applet.Applet;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class Clicker extends Applet implements ActionListener {

  InetAddress host;
  TextField text;

  public void init() {

    try {
      host = InetAddress.getByName(getCodeBase().getHost());
    } catch (UnknownHostException e) {
      System.out.println("Couldn't get Internet address: Unknown host");
      // What should we do?
    }
    
    butt("A");
    butt("B");
    butt("C");
    butt("#T");
    butt("#F");
    butt("Scheme Rules!");
    butt("Combination");
    butt("Error");
    text = new TextField("",20);
    text.addActionListener(this);
    add(text);
  }

  private void butt(String name) {
    Button butt = new Button(name);
    butt.addActionListener(this);
    add(butt);
  }

  public void actionPerformed(ActionEvent event) {
    try {
      Socket s = new Socket(host,8888);
      PrintWriter pw = new PrintWriter(s.getOutputStream());
      pw.println("vote");
      pw.println(event.getActionCommand());
      pw.flush();
      pw.close();
      s.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}
