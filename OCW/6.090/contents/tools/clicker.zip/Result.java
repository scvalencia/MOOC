
import java.util.*;
import java.net.*;

public class Result {

  int unique;
  int total;
  Set ips;

  public Result() {
    ips = new HashSet();
  }

  public void add(InetAddress addr) {
    total++;
    if (!ips.contains(addr)) {
      ips.add(addr);
      unique++;
    }
  }

}
